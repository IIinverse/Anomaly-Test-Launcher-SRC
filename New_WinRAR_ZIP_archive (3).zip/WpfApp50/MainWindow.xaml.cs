﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.CodeDom.Compiler;
using System.ComponentModel;

using System.IO;

using System.Reflection;
using System.Threading;

using System.Windows.Markup;
using ModernWpf.Controls;
using System.Windows.Forms;


namespace WpfApp50
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            ContentDialog contentDialog = new ContentDialog()
            {
                Title = "Launching",
                Content = "If you get an error Contanct the owner in the discord.",
                CloseButtonText = "Ok"
            };

            await contentDialog.ShowAsync();
            
        

            Process process3 = Process.Start("C:\\Users\\Vorty\\Desktop\\Launcher\\Fortnite (2252016-3240987)\\FortniteGame\\Binaries\\Win32\\FortniteClient-Win64-Shipping.exe");
         

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Process.Start("https://discord.gg/6AW2XCfR7G");
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            DLL dll = new DLL();
            dll.Show();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
          
            

        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.OpenFileDialog ofd = new System.Windows.Forms.OpenFileDialog();
            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textbox.Text = ofd.FileName;
            }
        }

    }
    }
